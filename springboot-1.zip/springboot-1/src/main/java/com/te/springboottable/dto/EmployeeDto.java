package com.te.springboottable.dto;

import lombok.Data;

@Data
public class EmployeeDto {
private String empId;
private String pan;
}
