package com.te.springboottable.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class SpringExceptionController {

	public ResponseEntity<?> getLogin() {
		return null;
		
	}
}
