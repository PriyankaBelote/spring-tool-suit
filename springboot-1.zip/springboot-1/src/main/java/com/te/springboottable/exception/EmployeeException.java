package com.te.springboottable.exception;

public class EmployeeException {

}
