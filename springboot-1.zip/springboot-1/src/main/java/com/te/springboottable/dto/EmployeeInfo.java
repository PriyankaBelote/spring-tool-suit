package com.te.springboottable.dto;

import lombok.Data;

@Data
public class EmployeeInfo {
private String empId;

}
